"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var EventsListComponent = (function () {
    //event: Event;
    function EventsListComponent() {
        this.title = "CapGemini Future Events List";
        this.subTitle = "Managed by HR Team of Pune";
        this.searchBy = "";
        this.events = [
            {
                eventId: 1,
                eventCode: 'CEPJQ3',
                eventName: 'jQuery 3 Seminar',
                description: 'jQuery 3 Seminar on new features',
                startDate: new Date(),
                endDate: new Date(),
                fees: 200,
                totalRegistration: 78,
                logo: 'images/jquery.png'
            },
            {
                eventId: 2,
                eventCode: 'CEPMS6',
                eventName: 'Microsoft MVC 6',
                description: 'Microsoft MVC 6 Seminar on new features',
                startDate: new Date(),
                endDate: new Date(),
                fees: 500,
                totalRegistration: 58,
                logo: 'images/mvc.png'
            },
            {
                eventId: 3,
                eventCode: 'CEPNG4',
                eventName: 'Angular 4 Seminar',
                description: 'Angular 4 Seminar on new features',
                startDate: new Date(),
                endDate: new Date(),
                fees: 800,
                totalRegistration: 98,
                logo: 'images/angular.png'
            },
            {
                eventId: 4,
                eventCode: 'CEPNG2',
                eventName: 'Angular 2 Seminar',
                description: 'Angular 2 Seminar on new features',
                startDate: new Date(),
                endDate: new Date(),
                fees: 300,
                totalRegistration: 68,
                logo: 'images/angular.png'
            },
            {
                eventId: 5,
                eventCode: 'CEPNG1',
                eventName: 'Angular JS 1.x Seminar',
                description: 'Angular JS 1.x Seminar on new features',
                startDate: new Date(),
                endDate: new Date(),
                fees: 400,
                totalRegistration: 88,
                logo: 'images/angular.png'
            }
        ];
        //this.event = new Event(1, 'CEPJQ3', 'jQuery 3 Seminar', 'Seminar on jQuery 3 New Features', new Date(), new Date(), 200, 45, 'images/jquery.png');
    }
    EventsListComponent.prototype.showEventDetails = function (event) {
        this.selectedEvent = event;
    };
    return EventsListComponent;
}());
EventsListComponent = __decorate([
    core_1.Component({
        selector: 'events-list',
        templateUrl: 'app/events/views/events-list.component.html'
    }),
    __metadata("design:paramtypes", [])
], EventsListComponent);
exports.EventsListComponent = EventsListComponent;
//# sourceMappingURL=events-list.component.js.map