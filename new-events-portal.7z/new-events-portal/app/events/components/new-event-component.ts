import { Component, OnInit } from '@angular/core';
import { Event } from "../models/event";
import { EventsService } from "../services/events.service";

@Component({
    selector: 'new-event',
    templateUrl: 'app/events/views/new-event-component.html'
})

export class NewEventComponent implements OnInit {
    constructor(private _eventsService:EventsService) { }
    title: string ="Register New Event!";
    newEvent:Event;
    
    ngOnInit() {

        registerNewEvent(){

            this._eventsService.insertNewEvent(this.newEvent)

        }


     }
}