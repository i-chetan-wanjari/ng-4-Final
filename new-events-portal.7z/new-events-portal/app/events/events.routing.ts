import { RouterModule,Routes } from "@angular/router";
import { ModuleWithProviders } from "@angular/core";

import { EventsListComponent } from "./components/events-list.component";
import { EventDetailsComponent } from "./components/event-details.component";
import { NewEventComponent } from "./components/new-event-component";

const eventsRoutes:Routes=[
{
    path:'',
    component :EventsListComponent


},
{
        path:':register',
        component :NewEventComponent
    },
    {
        path:':id',
        component :EventDetailsComponent
    }

];


export const eventsRouting:ModuleWithProviders =
RouterModule.forChild(eventsRoutes);


