import { ModuleWithProviders } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";

import { HomeComponent } from "./home/components/home.component";
import { EventsListComponent } from "./events/components/events-list.component";
import { EventDetailsComponent } from "./events/components/event-details.component";
import { PostListComponent } from "./jsonplaceholder/components/posts-list.components";


const homeRoutes: Routes = [
    {
        path: 'home',
        loadChildren: 'app/home/home.module#HomeModule'
    },
];

const eventRoutes: Routes = [
    {
        path: 'events',
        loadChildren: 'app/events/events.module#EventsModule'
    },
];

const jsonRoutes: Routes = [
    {
        path: 'jsonplaceholder',
        loadChildren: 'app/jsonplaceholder/jsonplaceholder.module#JsonPlaceholderModule'
    },
];

const appRoutes: Routes = [
    {
        path: '',
        redirectTo:'/home',
        pathMatch: 'full'
    },
    // { path: '**',
    //  component: HomeComponent
    //  }//Page Not Found Component should be implemented for not for routes
];


const rootRoutes: Routes=[
    ...homeRoutes,
    ...eventRoutes,
    ...jsonRoutes,
    ...appRoutes


]

export const routing: ModuleWithProviders = RouterModule.forRoot(rootRoutes);