import { RouterModule,Routes } from "@angular/router";
import { ModuleWithProviders } from "@angular/core";
import { HomeComponent } from './components/home.component';

const homeRoute:Routes=[

{
    path:'',
    component:HomeComponent

}

];

export const homeRouting:ModuleWithProviders=RouterModule.forChild(homeRoute)