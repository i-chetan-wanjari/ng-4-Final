import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { routing } from "./app.routing";
import { HomeComponent } from "./home/components/home.component";

//Custom Modules
import { EventsModule } from "./events/events.module";
import { JsonPlaceholderModule } from "./jsonplaceholder/jsonplaceholder.module";

// Componets
import { AppComponent } from './app.component';
import { EventsMenuComponent } from './navigation/components/events-menu-component';



//Services


@NgModule({
    // imports: [BrowserModule, EventsModule, JsonPlaceholderModule, HomeModule, routing], /// Other modules
     imports: [BrowserModule, routing], /// Other modules
    declarations: [AppComponent, EventsMenuComponent], // Pipes, directives, components
    exports: [],  //what u can access out side the module
    providers: [], // Services
    bootstrap: [AppComponent] /// Root componet name
})
export class AppModule {

}