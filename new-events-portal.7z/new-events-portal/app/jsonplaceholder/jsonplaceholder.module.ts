import { NgModule } from '@angular/core';
import { HttpModule } from "@angular/http";
import { CommonModule } from "@angular/common";
import { routing  } from "./jsonplaceholder.routing";

import { PostListComponent } from './components/posts-list.components';


import { PostsService } from './services/posts.service';

@NgModule({
    imports: [HttpModule, CommonModule,routing],
    exports: [PostListComponent],
    declarations: [PostListComponent],
    providers: [PostsService],
})
export class JsonPlaceholderModule { }
