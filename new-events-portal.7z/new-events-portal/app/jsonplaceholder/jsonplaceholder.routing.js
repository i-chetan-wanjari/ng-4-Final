"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var router_1 = require("@angular/router");
var posts_list_components_1 = require("./components/posts-list.components");
var appRoute = [
    {
        path: '',
        component: posts_list_components_1.PostListComponent
    }
];
exports.routing = router_1.RouterModule.forRoot(appRoute);
//# sourceMappingURL=jsonplaceholder.routing.js.map