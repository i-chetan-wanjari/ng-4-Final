export class Post{
    constructor(){

    }
    userID:number;
    id:number;
    title:string;
    body:string;
}