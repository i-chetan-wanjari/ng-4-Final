import {Component, OnInit} from "@angular/core";
import {Post} from '../models/post';
import{PostsService} from '../services/posts.service';

@Component({
    selector:"post-list",
    templateUrl:'app/jsonplaceholder/views/posts-list.component.html'
})

export class PostListComponent implements OnInit{
    constructor(private _postservice:PostsService){

    }
    posts:Post[];
    ngOnInit():void{
        this._postservice.getPosts().subscribe(
            data => this.posts=data,
            err => alert(err),
            () => console.log("Completed")
            
        )
    }
}