import { RouterModule,Routes } from "@angular/router";
import { ModuleWithProviders } from "@angular/core";

import { PostListComponent } from './components/posts-list.components';

const appRoute:Routes=[

{
    path:'',
    component:PostListComponent    
}

];

export const routing:ModuleWithProviders=RouterModule.forRoot(appRoute);