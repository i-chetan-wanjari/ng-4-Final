"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var router_1 = require("@angular/router");
var homeRoutes = [
    {
        path: 'home',
        loadChildren: 'app/home/home.module#HomeModule'
    },
];
var eventRoutes = [
    {
        path: 'events',
        loadChildren: 'app/events/events.module#EventsModule'
    },
];
var jsonRoutes = [
    {
        path: 'jsonplaceholder',
        loadChildren: 'app/jsonplaceholder/jsonplaceholder.module#JsonPlaceholderModule'
    },
];
var appRoutes = [
    {
        path: '',
        redirectTo: '/home',
        pathMatch: 'full'
    },
];
var rootRoutes = homeRoutes.concat(eventRoutes, jsonRoutes, appRoutes);
exports.routing = router_1.RouterModule.forRoot(rootRoutes);
//# sourceMappingURL=app.routing.js.map