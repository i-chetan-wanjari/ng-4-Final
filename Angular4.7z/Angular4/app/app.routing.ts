import { ModuleWithProviders } from "@angular/core";
import { RouterModule,Routes } from "@angular/router";


const appRoute: Routes=[
    { path:'home',},
    {path:'events',},
    {path:'posts',},
    {path:'',
     redirectTo:'home',
     pathMatch:'full'   }

]