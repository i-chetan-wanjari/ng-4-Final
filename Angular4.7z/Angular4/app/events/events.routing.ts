import { RouterModule,Routes } from "@angular/router";


const eventsRoutes:Routes=[
{
path:"",
components:

}

]