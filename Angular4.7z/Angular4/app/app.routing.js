"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var appRoute = [
    { path: 'home', },
    { path: 'events', },
    { path: 'posts', },
    { path: '',
        redirectTo: 'home',
        pathMatch: 'full' }
];
//# sourceMappingURL=app.routing.js.map